/sbin/shutdown -r now
