./ethdcrminer64 -epool us1.ethpool.org:3333 -ewal 0xa10927bff2fd2485fe1a24150d917dc24d3dfb36 -epsw x -dpool stratum+tcp://dcr.suprnova.cc:2252 -dwal Redhex.my -dpsw x
